// Temporary review probe: zoomToSelection in isolation, and the size of what _yScaleNeighbours feeds _autoYAxis
const path = require('path');
const { openCard } = require(path.join(process.cwd(), 'tests/lib.cjs'));

(async () => {
    const out = {};
    const card = range => ({ type: 'custom:history-explorer-card', defaultTimeRange: range, statistics: { enabled: false },
        graphs: [{ type: 'line', entities: [{ entity: 'sensor.power' }] }] });
    for( const range of ['24h', '7d', '30d'] ) {
        const t = await openCard(card(range), { mock: { series: true } });
        await t.wait(3000);
        const info = () => t.E(`(()=>{ const I=el.instance; const [n0,n1]=I.yScaleSlots(); const g=I.graphs[0];
            const nb=[...I._yScaleNeighbours(g.chart, 'y-axis-0', y=>y).values()].map(a=>a.length);
            return { rows: I.cacheRows(), slots: [n0, n1, I.cache.length], neighbours: nb, range: I.activeRange.timeRangeHours }; })()`);
        out[range + ' before'] = await info();
        out[range + ' sel'] = await t.E(`(()=>{ const I=el.instance; const s0=Date.parse(I.startTime), e0=Date.parse(I.endTime);
            try { I.zoomToSelection(0.1, 0.5); } catch(e) { return { error: String(e.message), at: String(e.stack).split('\\n').slice(0,3).join(' | ') }; }
            const s=Date.parse(I.startTime), e=Date.parse(I.endTime);
            return { selHours: Math.round((e0-s0)*0.4/3600e3), rangeHours: I.activeRange.timeRangeHours, covers: s <= s0+(e0-s0)*0.1 && e >= s0+(e0-s0)*0.5 }; })()`);
        await t.wait(1500);
        out[range + ' after'] = await info();
        out[range + ' errors'] = t.errors.slice();
        await t.close();
    }
    // a 30-day window: 15 and 27 days selected, from a fresh page each time
    for( const [f0, f1, label] of [[0.2, 0.7, '15d'], [0.05, 0.95, '27d']] ) {
        const t = await openCard(card('30d'), { mock: { series: true } });
        await t.wait(3000);
        out['30d ' + label] = await t.E(`(()=>{ const I=el.instance; const s0=Date.parse(I.startTime), e0=Date.parse(I.endTime);
            try { I.zoomToSelection(${f0}, ${f1}); } catch(e) { return { error: String(e.message) }; }
            const s=Date.parse(I.startTime), e=Date.parse(I.endTime);
            return { selHours: Math.round((e0-s0)*(${f1}-${f0})/3600e3), rangeHours: I.activeRange.timeRangeHours, covers: s <= s0+(e0-s0)*${f0} && e >= s0+(e0-s0)*${f1} }; })()`);
        await t.close();
    }
    console.log(JSON.stringify(out, null, 1));
})().catch(e => { console.error(e); process.exit(1); });
