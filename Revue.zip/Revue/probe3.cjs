// Temporary review probe: the stack overflow seen in probe1 — setTimeRangeFromString then zoomToSelection in one task
const path = require('path');
const { openCard } = require(path.join(process.cwd(), 'tests/lib.cjs'));

(async () => {
    const out = {};
    const card = { type: 'custom:history-explorer-card', defaultTimeRange: '30d', statistics: { enabled: false },
        graphs: [{ type: 'line', entities: [{ entity: 'sensor.power' }] }] };
    const t = await openCard(card, { mock: { series: true } });
    await t.wait(800);
    out.r = await t.E(`(()=>{ const I=el.instance, log=[]; const o=I._yScaleNeighbours;
        I._yScaleNeighbours = function(c, id, v){ const m=o.call(this, c, id, v); log.push({ sizes: [...m.values()].map(a=>a.length), rows: I.cacheRows(), slots: I.yScaleSlots(), cache: I.cache.length, range: I.activeRange.timeRangeHours }); return m; };
        const op = Array.prototype.push; let maxPush = 0; Array.prototype.push = function(){ if( arguments.length > maxPush ) maxPush = arguments.length; return op.apply(this, arguments); };
        let err = null;
        try { I.setTimeRangeFromString('30d', true); log.push('--- zoom'); I.zoomToSelection(0.1, 0.5); } catch(e) { err = { msg: e.message, stack: String(e.stack).split('\\n').slice(0,4).join(' | ') }; }
        Array.prototype.push = op; I._yScaleNeighbours = o;
        return { err, maxPush, log }; })()`);
    out.errors = t.errors.slice();
    await t.close();
    console.log(JSON.stringify(out, null, 1));
})().catch(e => { console.error(e); process.exit(1); });
