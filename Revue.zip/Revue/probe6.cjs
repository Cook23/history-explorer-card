// Temporary review probe: a chatty sensor (a value every 2 s), statistics off, a 3-day window — the
// background fills the days around it; _autoYAxis spreads a curve's neighbours into push(): the
// V8 limit (~130 000 arguments in this Chromium) reached?
const path = require('path');
const { openCard } = require(path.join(process.cwd(), 'tests/lib.cjs'));

(async () => {
    const out = { ticks: [] };
    const card = { type: 'custom:history-explorer-card', defaultTimeRange: '3d', statistics: { enabled: false },
        graphs: [{ type: 'line', entities: [{ entity: 'sensor.power' }] }] };
    const t = await openCard(card, { mock: { series: true, historyStep: 2 }, height: 700 });
    const info = () => t.E(`(()=>{ const I=el.instance; const g=I.graphs[0]; let nb=null; try { nb=[...I._yScaleNeighbours(g.chart, 'y-axis-0', y=>y).values()].map(a=>a.length); } catch(e) { nb='ERR '+e.message; }
        return { rows: I.cacheRows(), neighbours: nb, requests: window.__ws.length, loading: I.state.loading }; })()`);
    for( let k = 0; k < 12; k++ ) { await t.wait(5000); out.ticks.push(await info()); if( t.errors.length ) break; }
    // (a redraw asked now, as a refresh or an answer would)
    out.redraw = await t.E(`(()=>{ try { el.instance.generateGraphDataFromCache('the test'); return 'ok'; } catch(e) { return 'ERR ' + e.message + ' @ ' + String(e.stack).split('\\n')[1]; } })()`);
    out.pageErrors = t.errors.slice();
    await t.close();
    console.log(JSON.stringify(out, null, 1));
})().catch(e => { console.error(e); process.exit(1); });
