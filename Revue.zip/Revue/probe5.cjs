// Temporary review probe: V8's spread limit in this Chromium, and probe1-A replayed 3 times (the overflow seen once)
const path = require('path');
const { openCard } = require(path.join(process.cwd(), 'tests/lib.cjs'));

(async () => {
    const out = {};
    const card = { type: 'custom:history-explorer-card', defaultTimeRange: '30d', statistics: { enabled: false },
        graphs: [{ type: 'line', entities: [{ entity: 'sensor.power' }] }] };
    let t = await openCard(card, { mock: { series: true } });
    out.spread = await t.E(`[30000, 60000, 100000, 130000, 200000, 300000].map(n => { try { const a = []; a.push(...new Array(n).fill(0)); return n + ': ok'; } catch(e) { return n + ': ' + e.message; } })`);
    // (the same spread from a deeper stack, as _autoYAxis is reached from an evaluate: 12 frames down)
    out.spreadDeep = await t.E(`(()=>{ const deep = (k, f) => k ? deep(k - 1, f) : f(); return [30000, 60000, 100000].map(n => { try { return deep(60, () => { const a = []; a.push(...new Array(n).fill(0)); return n + ': ok'; }); } catch(e) { return n + ': ' + e.message; } }); })()`);
    await t.close();
    for( let k = 0; k < 3; k++ ) {
        t = await openCard(card, { mock: { series: true } });
        await t.wait(800);
        out['replay' + k] = await t.E(`(()=>{ const I=el.instance; const op = Array.prototype.push; let maxPush = 0; Array.prototype.push = function(){ if( arguments.length > maxPush ) maxPush = arguments.length; return op.apply(this, arguments); };
            let err = null; try { I.setTimeRangeFromString('30d', true); I.zoomToSelection(0.1, 0.5); } catch(e) { err = e.message; } Array.prototype.push = op;
            return { err, maxPush, rows: I.cacheRows(), range: I.activeRange.timeRangeHours }; })()`);
        out['replay' + k + ' pageErrors'] = t.errors.slice();
        await t.close();
    }
    console.log(JSON.stringify(out, null, 1));
})().catch(e => { console.error(e); process.exit(1); });
