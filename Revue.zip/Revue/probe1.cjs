// Temporary review probes (not part of the repository): run from the repo's tests dir context
const path = require('path');
const { openCard } = require(path.join(process.cwd(), 'tests/lib.cjs'));

(async () => {
    const out = {};
    // ── A: zoomToSelection — does the range cover the selection? ──
    let t = await openCard({ type: 'custom:history-explorer-card', defaultTimeRange: '30d', statistics: { enabled: false },
        graphs: [{ type: 'line', entities: [{ entity: 'sensor.power' }] }] }, { mock: { series: true } });
    await t.wait(800);
    const sel = async (f0, f1) => t.E(`(()=>{ const I=el.instance; I.setTimeRangeFromString('30d', true); const s0=Date.parse(I.startTime), e0=Date.parse(I.endTime);
        I.zoomToSelection(${f0}, ${f1}); const s=Date.parse(I.startTime), e=Date.parse(I.endTime);
        return { selHours: Math.round((e0-s0)*(${f1}-${f0})/3600e3), rangeHours: I.activeRange.timeRangeHours, covers: s <= s0+(e0-s0)*${f0} && e >= s0+(e0-s0)*${f1} }; })()`);
    out.A_12days = await sel(0.1, 0.5);     // 12 days selected
    out.A_27days = await sel(0.05, 0.95);   // 27 days
    out.A_15days = await sel(0.2, 0.7);     // 15 days
    await t.E(`el.instance.setTimeRangeFromString('5y', true)`); await t.wait(300);
    out.A_2years = await t.E(`(()=>{ const I=el.instance; const s0=Date.parse(I.startTime), e0=Date.parse(I.endTime); I.zoomToSelection(0.1, 0.5);
        return { selDays: Math.round((e0-s0)*0.4/864e5), rangeHours: I.activeRange.timeRangeHours }; })()`);
    await t.close();

    // ── B: a card-level lineWidth change in the YAML, with enable_persistence: entities ──
    t = await openCard({ type: 'custom:history-explorer-card', defaultTimeRange: '24', statistics: { enabled: false }, enable_persistence: 'entities',
        graphs: [{ type: 'line', entities: [{ entity: 'sensor.power' }] }] }, { mock: { series: true } });
    await t.wait(1200);
    const widthNow = () => t.E(`(()=>{ const I=el.instance; return { entry: I.pconfig.entities[0].width, drawn: I.graphs[0].chart.data.datasets[0].borderWidth, dash: I.pconfig.entities[0].dashMode, saved: JSON.parse(localStorage.getItem('history-explorer_card_'+I.id)).entities[0].width }; })()`);
    out.B_before = await widthNow();
    const name = await t.E('window.CFG.cardName');
    await t.page.addInitScript(c => { window.CFG = c; }, { type: 'custom:history-explorer-card', defaultTimeRange: '24', statistics: { enabled: false }, enable_persistence: 'entities', lineWidth: 6, dashMode: 'shortlines',
        graphs: [{ type: 'line', entities: [{ entity: 'sensor.power' }] }], cardName: name });
    await t.page.reload(); await t.wait(2500);
    out.B_afterYamlLineWidth6 = await widthNow();
    // (the same without persistence)
    await t.E('localStorage.clear()'); await t.page.reload(); await t.wait(2500);
    out.B_freshDevice = await widthNow();
    await t.close();

    // ── C: statistics.period: 5minute — is the probe run? are 5-minute statistics drawn for a sparse sensor? ──
    t = await openCard({ type: 'custom:history-explorer-card', defaultTimeRange: '7d', statistics: { enabled: true, period: '5minute' },
        graphs: [{ type: 'line', entities: [{ entity: 'sensor.power' }] }] }, { mock: { series: true, historyStep: 3600 } });
    await t.wait(4000);
    out.C = await t.E(`(()=>{ const I=el.instance; const ws=window.__ws.map(w=>w.type.split('/')[0]+':'+(w.period??'')); const d=I.graphs[0].chart.data.datasets[0].data;
        return { requests: [...new Set(ws)], fineValid: I._relevant('sensor.power', 300e3), probeKept: localStorage.getItem('history-explorer_probes'), statsPoints: d.filter(p=>p.statistics).length, points: d.length }; })()`);
    await t.close();
    // (the same with the default period: the probe refuses the 5-minute statistics of a sensor speaking once an hour)
    t = await openCard({ type: 'custom:history-explorer-card', defaultTimeRange: '7d', statistics: { enabled: true },
        graphs: [{ type: 'line', entities: [{ entity: 'sensor.power' }] }] }, { mock: { series: true, historyStep: 3600 } });
    await t.wait(4000);
    out.C_default = await t.E(`(()=>{ const I=el.instance; const ws=window.__ws.map(w=>w.type.split('/')[0]+':'+(w.period??'')); const d=I.graphs[0].chart.data.datasets[0].data;
        return { requests: [...new Set(ws)], fineValid: I._relevant('sensor.power', 300e3), statsPoints: d.filter(p=>p.statistics).length, points: d.length }; })()`);
    await t.close();
    console.log(JSON.stringify(out, null, 1));
})().catch(e => { console.error(e); process.exit(1); });
