// Temporary review probes B and C (see probe1)
const path = require('path');
const { openCard } = require(path.join(process.cwd(), 'tests/lib.cjs'));

(async () => {
    const out = {};
    // ── B: a card-level lineWidth / dashMode change in the YAML, with enable_persistence: entities ──
    let t = await openCard({ type: 'custom:history-explorer-card', defaultTimeRange: '24', statistics: { enabled: false }, enable_persistence: 'entities',
        graphs: [{ type: 'line', entities: [{ entity: 'sensor.power' }] }] }, { mock: { series: true } });
    await t.wait(1500);
    const widthNow = () => t.E(`(()=>{ const I=el.instance; const e=I.pconfig.entities[0]; return { entryWidth: e.width, entryDash: e.dashMode, entryShowPoints: e.showPoints, drawnWidth: I.graphs[0].chart.data.datasets[0].borderWidth, drawnDash: I.graphs[0].chart.data.datasets[0].borderDash,
        savedKeys: Object.keys(JSON.parse(localStorage.getItem('history-explorer_card_'+I.id)).entities[0]).sort().join(',') }; })()`);
    out.B_before = await widthNow();
    const name = await t.E('window.CFG.cardName');
    await t.page.addInitScript(c => { window.CFG = c; }, { type: 'custom:history-explorer-card', defaultTimeRange: '24', statistics: { enabled: false }, enable_persistence: 'entities', lineWidth: 6, dashMode: 'shortlines',
        graphs: [{ type: 'line', entities: [{ entity: 'sensor.power' }] }], cardName: name });
    await t.page.reload(); await t.wait(2500);
    out.B_afterYamlLineWidth6 = await widthNow();
    await t.E('localStorage.clear()'); await t.page.reload(); await t.wait(2500);
    out.B_freshDevice = await widthNow();
    await t.close();

    // ── C: statistics.period: 5minute — the probe, the 5-minute statistics of a sparse sensor ──
    for( const [label, stats] of [['5minute', { enabled: true, period: '5minute' }], ['default', { enabled: true }]] ) {
        t = await openCard({ type: 'custom:history-explorer-card', defaultTimeRange: '7d', statistics: stats,
            graphs: [{ type: 'line', entities: [{ entity: 'sensor.power' }] }] }, { mock: { series: true, historyStep: 3600 } });
        await t.wait(4000);
        out['C_' + label] = await t.E(`(()=>{ const I=el.instance; const ws=window.__ws.map(w=>w.type.split('/')[0]+':'+(w.period??'')); const d=I.graphs[0].chart.data.datasets[0].data;
            return { requests: [...new Set(ws)], fineValid: I._relevant('sensor.power', 300e3), probeKept: localStorage.getItem('history-explorer_probes'), statsPoints: d.filter(p=>p.statistics).length, points: d.length, source: I._sourceNeeded() }; })()`);
        await t.close();
    }
    console.log(JSON.stringify(out, null, 1));
})().catch(e => { console.error(e); process.exit(1); });
